function showResult() {
	var  p = 2;
	console.log(this);
	document.getElementById('result').innerHTML = 
	document.getElementById('lName').value + document.getElementById('uName').value
	+ document.getElementById('pName').value + document.getElementById('sName').value
	+document.getElementById('lupName').value + document.getElementById('dName').value;
}

function showResult1() {
	alert(1)
}

// alert(p);
// window.alert(2);
window.console.info(window.document)

var p = 10;
