function showResult() {
	console.log(this);
	document.getElementById('result').innerHTML = 
	document.getElementById('fName').value + document.getElementById('lName').value
	+document.getElementById('Mnumber').valur+document.getElementById('Eid').value;
}
