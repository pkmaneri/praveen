function function_name(praveen) {
	const obj ={};
	obj.name = praveen
	obj.getting = function(){
		alert ( "Hi" i |"m" + obj.name +"..");
	}
	return obj;
}