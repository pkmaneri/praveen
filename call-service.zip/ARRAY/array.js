var groceries =["milk","egg",];
for( var i = 0;i < groceries.length; i++){
	var item = groceries [i];
	console.log(item);

}
var groceries = ["milk","egg"];
groceries.push("cookies");
for( var i = 0;i < groceries.length; i++){
	var item = groceries [i];
	console.log(item);

}

groceries.pop();
